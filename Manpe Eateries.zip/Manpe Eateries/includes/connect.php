<?php
session_start();
$servername = "localhost";
$server_user = "vrumao";
$server_pass = "047869Vr";
$dbname = "db_vrumao";
$name = $_SESSION['name'];
$role = $_SESSION['role'];
$con = new mysqli($servername, $server_user, $server_pass, $dbname);
?>